l=int(input("enter the limit:"))
even=[]
odd=[]
for i in range(l):
    n=int(input("Enter the values:"))
    if n%2==0:
        even.append(n)
    else:
        odd.append(n)
print("number of even numbers:",len(even))
print("number of even numbers:",len(odd))


