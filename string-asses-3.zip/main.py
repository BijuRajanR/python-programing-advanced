"""my_string="hello,world"
n=3
new_string=my_string[:n]+my_string[n+1:]
print(new_string)"""


"""my_string="liju, RaghuB"
new_string=my_string[-1]+my_string[1:-1]+my_string[0]
print(new_string)
#o/p the first letter and last letter will be changed"""



"""def reverse_string_if_multiple_of_six(my_string):
    if len(my_string)%6==0:
        return my_string[::-1]
    else:
         return my_string
         
my_string=input("Enter a string:")
new_string=reverse_string_if_multiple_of_six(my_string)
print(new_string)"""
