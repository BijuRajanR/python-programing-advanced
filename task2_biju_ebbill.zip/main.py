#eb bill
name=str(input("Enter your name:"))
cur_reading=int(input("Enter the current reading:"))
pre_reading=int(input("Enter the previous reading:"))
print("EBbill for",name)
cur_consumption=cur_reading-pre_reading
if (cur_consumption<500):
    print("the amount to pay=",cur_consumption*3/4)
elif(cur_consumption>=500 and cur_consumption<1000):
    print("the amount to pay=",cur_consumption*5/4)
elif(cur_consumption>=1000):
    print("the amount to pay=",cur_consumption*7/4)
else:
    print("unit is not acceptable..")