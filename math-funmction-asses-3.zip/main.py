"""def smallest_multiple(n):
    if (n <= 2):
        return n
    i = n * 2
    factors = [number for number in range(n, 1, -1) if number * 2 > n]
    print(factors)
    while True:
        for a in factors:
            if i % a != 0:
                i += n
                break
            if (a == factors[-1] and i % a == 0):
                return i

print(smallest_multiple(5))"""


"""import math
radians=float(input("Enter a value in radians:"))
degrees=math.degrees(radians)
print(radians,"radians is convert to",degrees,"degrees")
"""

# multiply 2 integers wiyhout using * 1
"""def multiply(x, y):
    if y < 0:
        return -multiply(x, -y)
    elif y == 0:
        return 0
    elif y == 1:
        return x
    else:
        return x + multiply(x, y - 1)

print(multiply(3, 5))"""

# multiply 2 integers wiyhout using * 2

"""num1=int(input("Enter the first integer:"))
num2=int(input("Enter the second integer:"))
product=0
for i in range(num2):
    product+=num1
print(num1,"times",num2,"equals",product)"""





