num=int(input("Enter the number:"))
a=num
sum=0
while num>0:
    rem=num%10
    fact=10
    for i in range(1,rem+1):
        fact*=i
    sum+=fact
    num//=10
if sum==a:
    print(a,"is a Strong Number")
else:
    print(a,"is a not Strong Number")