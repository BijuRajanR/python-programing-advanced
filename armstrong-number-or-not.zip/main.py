num=int(input("Enter a Number:"))
a=num
sum=0
while a>0:
    rem = a%10
    sum += rem**3
    a//=10
if num == sum:
    print(num,"is a Armstrong number")
else:
    print(num,"is a Not Armstrong number")
