"""my_list=[1,2,3,4,5]
sum_of_list=sum(my_list)
print(sum_of_list)"""


"""my_list=[1,2,3,4,5]
largest_number=max(my_list)
print(largest_number)"""


"""list1=[1,2,3,4,5]
list2=[5,6,7,8,9]
common_member=set(list1).intersection(list2)
if common_member:
    print("The list have at least oneb common member.,")
else:
    print("The list do not have any common members.")"""