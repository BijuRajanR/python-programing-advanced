a=int(input("enter a numb"))
if a>0:
    print("he numb is positive")
    if a%2==0:
        print("the numb is even")
    else:
        print("the numb is odd")
elif a==0:
    print("the numb is neutral")
else:
    print("the numb is negative")