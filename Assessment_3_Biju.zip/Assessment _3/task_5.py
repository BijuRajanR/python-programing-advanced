numbers = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
largest = max(numbers)
print("Largest number:", largest)
