my_tuple = (1, 2, 3, 3, 4, 4, 5)
my_set = set(my_tuple)
print("Converted Set:", my_set)
