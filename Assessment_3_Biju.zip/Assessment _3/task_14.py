set1 = {1, 2, 3}
set2 = {1, 2, 3, 4, 5}
is_subset = set1 <= set2  # Or use set1.issubset(set2)
print("Is set1 a subset of set2:", is_subset)
