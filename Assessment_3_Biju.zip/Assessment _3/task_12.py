tuple_of_tuples = ((3, 7), (1, 2), (5, 4))
sorted_tuples = sorted(tuple_of_tuples, key=lambda x: x[1])
print("Sorted Tuples:", sorted_tuples)
