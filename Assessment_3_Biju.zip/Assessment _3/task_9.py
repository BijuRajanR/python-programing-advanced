my_tuple = (1, 2, 3, 4, 5, 6, 7)
fourth_element = my_tuple[3]
fourth_from_last = my_tuple[-4]
print("4th Element:", fourth_element)
print("4th-from-last Element:", fourth_from_last)
