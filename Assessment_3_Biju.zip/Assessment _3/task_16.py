my_dict = {'a': 1, 'b': 2, 'c': 3}
key_to_check = input("Enter a key to check: ")
if key_to_check in my_dict:
    print("Key exists in the dictionary.")
else:
    print("Key does not exist in the dictionary.")
