basic_salary = float(input("Enter the basic salary: "))

if basic_salary < 1500:
    hra = 0.1 * basic_salary
    da = 0.9 * basic_salary
else:
    hra = 500
    da = 0.98 * basic_salary

gross_salary = basic_salary + hra + da
print("Gross Salary:", gross_salary)
