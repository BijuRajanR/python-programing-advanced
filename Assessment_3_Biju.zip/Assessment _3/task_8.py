input_string = input("Enter a string without spaces: ")
output_string = ' '.join(input_string)
print("Output:", output_string)