input_string = input("Enter a string: ")
vowels = {'a', 'e', 'i', 'o', 'u'}
vowel_count = sum(1 for char in input_string if char.lower() in vowels)
print("Number of vowels:", vowel_count)