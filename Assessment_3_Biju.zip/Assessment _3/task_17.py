my_dict = {'a': 10, 'b': 20, 'c': 30}
total_sum = sum(my_dict.values())
print("Sum of values:", total_sum)
