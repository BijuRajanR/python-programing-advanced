my_tuple = (("a", 1), ("b", 2), ("c", 3))
my_dict = dict(my_tuple)
print("Converted Dictionary:", my_dict)
