original_list = [int(x) for x in input("Enter numbers separated by spaces: ").split()]
unique_list = list(set(original_list))
print("List with duplicates removed:", unique_list)