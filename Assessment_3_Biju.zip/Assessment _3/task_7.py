original_list = [1, 2, 3, 4, 5]
copied_list = original_list.copy()
print("Copied List:", copied_list)
