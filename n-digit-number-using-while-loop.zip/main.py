num=int(input("Enter the number:"))
temp=num
sum=0
while num>0:
    rem=num%10
    sum=(sum*10)+rem
    num=num//10
print("before number:",temp)
print("reversed number:",sum)
