"""import datetime
now=datetime.datetime.now()
first_second=datetime.datetime(now.year,now.month,now.day,now.hour,now.minute,0,0)
last_second=datetime.datetime(now.year,now.month,now.day,now.hour,now.minute,59,999999)
print("The first second of the current date and time is:",first_second)
print("The last second of the current date abnd time is:",last_second)"""

"""import datetime
now=datetime.date.today()
last_tuesday=now-datetime.timedelta(days=now.weekday()-1)
print("The date of the last tuesday is:",last_tuesday)"""


"""import datetime
first_date_str=input("Enter the first date(YYYY-MM-DD):")
first_date=datetime.datetime.strptime(first_date_str,"%Y-%m-%d").date()
second_date_str=input("Enter the second date(YYYY-MM-DD):")
second_date=datetime.datetime.strptime(second_date_str,"%Y-%m-%d").date()
delta=second_date-first_date
num_days=delta.days
print("The number of the days between",first_date_str,"and",second_date_str,"is",num_days)"""